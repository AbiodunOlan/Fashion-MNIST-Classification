
#install.packages("keras")
#install.packages("tensorflow")
#install_keras()


library(keras)
library(tensorflow)


# Load and preprocess the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
c(c(train_images, train_labels), c(test_images, test_labels)) %<-% fashion_mnist

# Reshape the data to include channel dimension
train_images <- array_reshape(train_images, c(nrow(train_images), 28, 28, 1))
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))

# Normalize the images
train_images <- train_images / 255
test_images <- test_images / 255

# Define the CNN model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'sparse_categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model
model %>% fit(
  train_images, train_labels,
  epochs = 10, validation_data = list(test_images, test_labels)
)

# Evaluate the model
score <- model %>% evaluate(test_images, test_labels)
cat('Test accuracy:', score[[2]], "\n")



library(keras)
library(tensorflow)

# Load and preprocess the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
c(c(train_images, train_labels), c(test_images, test_labels)) %<-% fashion_mnist

# Reshape the data to include the channel dimension
train_images <- array_reshape(train_images, c(nrow(train_images), 28, 28, 1))
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))

# Normalize the images
train_images <- train_images / 255
test_images <- test_images / 255

# Define the CNN model (if not already defined)
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model (if not already compiled)
model %>% compile(
  optimizer = 'adam',
  loss = 'sparse_categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model (if not already trained)
model %>% fit(
  train_images, train_labels,
  epochs = 10, validation_data = list(test_images, test_labels)
)

# Make predictions
predictions <- model %>% predict(test_images)

# Function to plot images and predictions
plot_image <- function(index) {
  img <- test_images[index,, ,1]
  img <- t(apply(img, 2, rev))  # Flip the image
  plot(as.raster(img), main = paste("Prediction:", class_names[which.max(predictions[index, ])],
                                    "\nActual:", class_names[test_labels[index] + 1]))
}

# Class names for Fashion MNIST
class_names <- c('T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 
                 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot')

# Plot predictions for two images
par(mfrow = c(1, 2))
plot_image(1)  # Plot the first image
plot_image(2)  # Plot the second image


